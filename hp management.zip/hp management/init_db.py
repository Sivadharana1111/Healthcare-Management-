from app import create_app, db
from app.models import User, Doctor, Patient, Department, Appointment, MedicalRecord
from werkzeug.security import generate_password_hash
from datetime import datetime, date, time

def init_db():
    app = create_app()
    with app.app_context():
        # Drop all tables and recreate them
        db.drop_all()
        db.create_all()
        
        print("Creating departments...")
        # Create departments
        departments = [
            Department(name='Cardiology', description='Heart and cardiovascular system'),
            Department(name='Neurology', description='Brain and nervous system'),
            Department(name='Pediatrics', description='Children\'s health'),
            Department(name='Orthopedics', description='Bones and joints'),
            Department(name='General Medicine', description='General health conditions')
        ]
        db.session.add_all(departments)
        db.session.commit()
        print("Departments created successfully!")
        
        print("Creating admin user...")
        # Create admin user
        admin = User(
            name='Admin User',
            email='admin@hospital.com',
            password=generate_password_hash('admin123'),
            role='admin'
        )
        db.session.add(admin)
        db.session.commit()
        print("Admin user created successfully!")
        
        print("Creating sample doctors...")
        # Create sample doctors
        doctors = [
            {
                'name': 'Dr. John Smith',
                'email': 'john.smith@hospital.com',
                'specialization': 'Cardiology',
                'experience': 15,
                'qualification': 'MD, Cardiology',
                'consultation_fee': 100.00,
                'department_id': 1  # Cardiology
            },
            {
                'name': 'Dr. Sarah Johnson',
                'email': 'sarah.johnson@hospital.com',
                'specialization': 'Neurology',
                'experience': 12,
                'qualification': 'MD, Neurology',
                'consultation_fee': 120.00,
                'department_id': 2  # Neurology
            }
        ]
        
        for doctor_data in doctors:
            user = User(
                name=doctor_data['name'],
                email=doctor_data['email'],
                password=generate_password_hash('doctor123'),
                role='doctor'
            )
            db.session.add(user)
            db.session.commit()
            
            doctor = Doctor(
                user_id=user.id,
                department_id=doctor_data['department_id'],
                specialization=doctor_data['specialization'],
                experience=doctor_data['experience'],
                qualification=doctor_data['qualification'],
                consultation_fee=doctor_data['consultation_fee']
            )
            db.session.add(doctor)
            db.session.commit()
        
        print("Sample doctors created successfully!")
        print("Database initialized with sample data!")

if __name__ == '__main__':
    init_db() 
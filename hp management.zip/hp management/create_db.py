import pymysql
from app import create_app, db
from app.models import User, Doctor, Patient, Department, Appointment, MedicalRecord
from werkzeug.security import generate_password_hash
from datetime import datetime, date, time

def create_database():
    # Create the database if it doesn't exist
    connection = pymysql.connect(
        host='localhost',
        user='root',
        password=''
    )
    try:
        with connection.cursor() as cursor:
            cursor.execute('CREATE DATABASE IF NOT EXISTS hp_manage')
        print("Database created successfully!")
    except Exception as e:
        print(f"Error creating database: {e}")
    finally:
        connection.close()

def init_tables():
    app = create_app()
    with app.app_context():
        try:
            # Create all tables
            db.create_all()
            print("Tables created successfully!")
            
            # Create departments
            departments = [
                Department(name='Cardiology', description='Heart and cardiovascular system'),
                Department(name='Neurology', description='Brain and nervous system'),
                Department(name='Pediatrics', description='Children\'s health'),
                Department(name='Orthopedics', description='Bones and joints'),
                Department(name='General Medicine', description='General health conditions')
            ]
            db.session.add_all(departments)
            db.session.commit()
            print("Departments created successfully!")
            
            # Create admin user
            admin = User(
                name='Admin User',
                email='admin@hospital.com',
                password=generate_password_hash('admin123'),
                role='admin'
            )
            db.session.add(admin)
            db.session.commit()
            print("Admin user created successfully!")
            
            # Create sample doctors
            doctors = [
                {
                    'name': 'Dr. John Smith',
                    'email': 'john.smith@hospital.com',
                    'specialization': 'Cardiology',
                    'experience': 15,
                    'qualification': 'MD, Cardiology',
                    'consultation_fee': 100.00,
                    'department_id': 1  # Cardiology
                },
                {
                    'name': 'Dr. Sarah Johnson',
                    'email': 'sarah.johnson@hospital.com',
                    'specialization': 'Neurology',
                    'experience': 12,
                    'qualification': 'MD, Neurology',
                    'consultation_fee': 120.00,
                    'department_id': 2  # Neurology
                }
            ]
            
            for doctor_data in doctors:
                user = User(
                    name=doctor_data['name'],
                    email=doctor_data['email'],
                    password=generate_password_hash('doctor123'),
                    role='doctor'
                )
                db.session.add(user)
                db.session.commit()
                
                doctor = Doctor(
                    user_id=user.id,
                    department_id=doctor_data['department_id'],
                    specialization=doctor_data['specialization'],
                    experience=doctor_data['experience'],
                    qualification=doctor_data['qualification'],
                    consultation_fee=doctor_data['consultation_fee']
                )
                db.session.add(doctor)
                db.session.commit()
            print("Sample doctors created successfully!")
            
        except Exception as e:
            print(f"Error initializing tables: {e}")
            db.session.rollback()
        finally:
            db.session.close()

if __name__ == '__main__':
    create_database()
    init_tables()
    print("Database initialization completed!") 
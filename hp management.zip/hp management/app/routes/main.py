from flask import Blueprint, render_template, redirect, url_for

bp = Blueprint('main', __name__)

@bp.route('/')
def index():
    # Redirect to the login page
    return redirect(url_for('auth.login'))

# Removed placeholder dashboard routes from here.
# These will be handled by admin.py, doctor.py, and patient.py blueprints. 
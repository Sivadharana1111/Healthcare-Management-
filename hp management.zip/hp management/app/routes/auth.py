from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
from app.models import User, Patient, db
from datetime import datetime

bp = Blueprint('auth', __name__)

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role')
        
        # Find user by email and role
        user = User.query.filter_by(email=email, role=role).first()
        
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['role'] = user.role
            
            # Redirect based on role
            if role == 'admin':
                return redirect(url_for('admin.dashboard'))
            elif role == 'doctor':
                return redirect(url_for('doctor.dashboard'))
            else:
                return redirect(url_for('patient.dashboard'))
        
        flash('Invalid email, password, or role', 'error')
    return render_template('auth/login.html')

@bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        # User fields
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Patient fields
        date_of_birth_str = request.form.get('date_of_birth')
        gender = request.form.get('gender')
        phone = request.form.get('phone')
        address = request.form.get('address')
        blood_group = request.form.get('blood_group')
        medical_history = request.form.get('medical_history')

        # --- Validation ---
        if not name or not email or not password or not confirm_password:
            flash('Please fill in all required fields (Name, Email, Password, Confirm Password).', 'error')
            # Re-render form with entered data (optional, for better UX)
            return render_template('auth/register.html', **request.form)
        
        if password != confirm_password:
            flash('Passwords do not match', 'error')
            return render_template('auth/register.html', **request.form)
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered. Please login or use a different email.', 'error')
            return render_template('auth/register.html', **request.form)

        date_of_birth = None
        if date_of_birth_str:
            try:
                date_of_birth = datetime.strptime(date_of_birth_str, '%Y-%m-%d').date()
            except ValueError:
                flash('Invalid date format for Date of Birth. Please use YYYY-MM-DD.', 'error')
                return render_template('auth/register.html', **request.form)
        # --- End Validation ---
        
        try:
            # Create new User
            user = User(
                name=name,
                email=email,
                password=generate_password_hash(password),
                role='patient'
            )
            db.session.add(user)
            db.session.flush() # Important to get the user.id before creating Patient

            # Create new Patient linked to the User
            patient = Patient(
                user_id=user.id,
                date_of_birth=date_of_birth,
                gender=gender,
                phone=phone,
                address=address,
                blood_group=blood_group,
                medical_history=medical_history
            )
            db.session.add(patient)
            
            db.session.commit()
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('auth.login'))
        
        except Exception as e:
            db.session.rollback() # Rollback in case of error
            flash(f'An error occurred during registration: {str(e)}', 'error')
            # Log the error e for debugging
            print(f"Error during registration: {e}")
            return render_template('auth/register.html', **request.form)
    
    # GET request
    return render_template('auth/register.html')

@bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('main.index')) 
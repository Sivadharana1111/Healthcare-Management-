from flask import Blueprint, render_template, session, redirect, url_for, flash
from app.models import User, Doctor, Patient, Appointment, db
from datetime import date

bp = Blueprint('doctor', __name__, url_prefix='/doctor')

def get_doctor_id():
    """Gets the Doctor ID for the logged-in user."""
    if 'user_id' in session and session.get('role') == 'doctor':
        doctor = Doctor.query.filter_by(user_id=session['user_id']).first()
        return doctor.id if doctor else None
    return None

@bp.route('/dashboard')
def dashboard():
    doctor_id = get_doctor_id()
    if not doctor_id:
        flash('Access denied or Doctor profile not found.', 'error')
        return redirect(url_for('auth.login'))

    # Get upcoming appointments (today onwards)
    today = date.today()
    upcoming_appointments = Appointment.query \
        .filter(Appointment.doctor_id == doctor_id) \
        .filter(Appointment.appointment_date >= today) \
        .join(Patient, Appointment.patient_id == Patient.id) \
        .join(User, Patient.user_id == User.id) \
        .add_columns(User.name.label('patient_name'), Appointment.appointment_date, Appointment.appointment_time, Appointment.status) \
        .order_by(Appointment.appointment_date, Appointment.appointment_time) \
        .limit(5) \
        .all()

    return render_template('doctor/dashboard.html', appointments=upcoming_appointments)

@bp.route('/appointments')
def view_appointments():
    doctor_id = get_doctor_id()
    if not doctor_id:
        flash('Access denied or Doctor profile not found.', 'error')
        return redirect(url_for('auth.login'))

    all_appointments = Appointment.query \
        .filter(Appointment.doctor_id == doctor_id) \
        .join(Patient, Appointment.patient_id == Patient.id) \
        .join(User, Patient.user_id == User.id) \
        .add_columns(User.name.label('patient_name'), Appointment.appointment_date, Appointment.appointment_time, Appointment.status, Appointment.id) \
        .order_by(Appointment.appointment_date.desc(), Appointment.appointment_time.desc()) \
        .all()

    return render_template('doctor/appointments.html', appointments=all_appointments)

# Add other doctor routes here (e.g., view appointments, manage schedule, view patient records) 
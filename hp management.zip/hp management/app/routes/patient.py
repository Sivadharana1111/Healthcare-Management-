from flask import Blueprint, render_template, session, redirect, url_for, flash, request
from app.models import User, Doctor, Patient, Appointment, Department, MedicalRecord, db
from datetime import date, datetime, time

bp = Blueprint('patient', __name__, url_prefix='/patient')

def get_patient_id():
    """Gets the Patient ID for the logged-in user."""
    if 'user_id' in session and session.get('role') == 'patient':
        patient = Patient.query.filter_by(user_id=session['user_id']).first()
        return patient.id if patient else None
    return None

@bp.route('/dashboard')
def dashboard():
    patient_id = get_patient_id()
    if not patient_id:
        flash('Access denied or Patient profile not found.', 'error')
        return redirect(url_for('auth.login'))

    # Get upcoming appointments (today onwards)
    today = date.today()
    upcoming_appointments = Appointment.query \
        .filter(Appointment.patient_id == patient_id) \
        .filter(Appointment.appointment_date >= today) \
        .join(Doctor, Appointment.doctor_id == Doctor.id) \
        .join(User, Doctor.user_id == User.id) \
        .add_columns(User.name.label('doctor_name'), Doctor.specialization, Appointment.appointment_date, Appointment.appointment_time, Appointment.status) \
        .order_by(Appointment.appointment_date, Appointment.appointment_time) \
        .limit(5) \
        .all()

    return render_template('patient/dashboard.html', appointments=upcoming_appointments)

@bp.route('/book_appointment', methods=['GET', 'POST'])
def book_appointment():
    patient_id = get_patient_id()
    if not patient_id:
        flash('Please log in to book an appointment.', 'error')
        return redirect(url_for('auth.login'))

    if request.method == 'POST':
        doctor_id = request.form.get('doctor_id')
        appointment_date_str = request.form.get('appointment_date')
        appointment_time_str = request.form.get('appointment_time')
        reason = request.form.get('reason')

        try:
            appointment_date = datetime.strptime(appointment_date_str, '%Y-%m-%d').date()
            appointment_time = datetime.strptime(appointment_time_str, '%H:%M').time()
        except ValueError:
            flash('Invalid date or time format.', 'error')
            return redirect(url_for('patient.book_appointment'))

        # Basic check: Prevent booking in the past
        if appointment_date < date.today() or \
           (appointment_date == date.today() and appointment_time < datetime.now().time()):
            flash('Cannot book appointments in the past.', 'error')
            return redirect(url_for('patient.book_appointment'))

        # TODO: Add more validation (e.g., check doctor availability, prevent double booking)

        new_appointment = Appointment(
            doctor_id=doctor_id,
            patient_id=patient_id,
            appointment_date=appointment_date,
            appointment_time=appointment_time,
            reason=reason,
            status='pending' # Default status
        )
        db.session.add(new_appointment)
        db.session.commit()

        flash('Appointment booked successfully! It is pending confirmation.', 'success')
        return redirect(url_for('patient.dashboard'))

    # GET request: Show booking form
    doctors = Doctor.query.join(User, Doctor.user_id == User.id).add_columns(User.name, Doctor.specialization, Doctor.id).filter(Doctor.available == True).all()
    return render_template('patient/book_appointment.html', doctors=doctors)

@bp.route('/medical_history')
def medical_history():
    patient_id = get_patient_id()
    if not patient_id:
        flash('Please log in to view your history.', 'error')
        return redirect(url_for('auth.login'))

    # Fetch medical records (placeholder for now)
    records = MedicalRecord.query.filter_by(patient_id=patient_id).order_by(MedicalRecord.created_at.desc()).all()
    return render_template('patient/medical_history.html', records=records)

# Add other patient routes here (e.g., book appointment, view medical history, update profile) 
from flask import Blueprint, render_template, session, redirect, url_for, request, flash
from app.models import User, Doctor, Patient, Department, db
from werkzeug.security import generate_password_hash

bp = Blueprint('admin', __name__, url_prefix='/admin')

def is_admin():
    """Checks if the current user is logged in as an admin."""
    return 'user_id' in session and session.get('role') == 'admin'

@bp.route('/dashboard')
def dashboard():
    if not is_admin():
        return redirect(url_for('auth.login'))
    return render_template('admin/dashboard.html')

# Doctor Management
@bp.route('/doctors')
def manage_doctors():
    if not is_admin():
        return redirect(url_for('auth.login'))
    
    doctors = Doctor.query.join(User, Doctor.user_id == User.id).add_columns(
        User.name,
        User.email,
        Doctor.specialization,
        Doctor.id
    ).all()
    
    return render_template('admin/manage_doctors.html', doctors=doctors)

@bp.route('/doctors/add', methods=['GET', 'POST'])
def add_doctor():
    if not is_admin():
        return redirect(url_for('auth.login'))
    
    departments = Department.query.all()
    
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        specialization = request.form.get('specialization')
        department_id = request.form.get('department_id')
        qualification = request.form.get('qualification')
        experience = request.form.get('experience')
        consultation_fee = request.form.get('consultation_fee')
        
        # Check if email exists
        if User.query.filter_by(email=email).first():
            flash('Email already exists.', 'error')
            return redirect(url_for('admin.add_doctor'))

        # Create User
        user = User(
            name=name,
            email=email,
            password=generate_password_hash(password),
            role='doctor'
        )
        db.session.add(user)
        db.session.flush()  # Get the user ID before committing

        # Create Doctor
        doctor = Doctor(
            user_id=user.id,
            department_id=department_id,
            specialization=specialization,
            qualification=qualification,
            experience=experience,
            consultation_fee=consultation_fee
        )
        db.session.add(doctor)
        db.session.commit()
        
        flash('Doctor added successfully!', 'success')
        return redirect(url_for('admin.manage_doctors'))

    return render_template('admin/add_doctor.html', departments=departments)

# Add routes for editing and deleting doctors here...

# Patient Management
@bp.route('/patients')
def manage_patients():
    if not is_admin():
        return redirect(url_for('auth.login'))
    
    patients = Patient.query.join(User, Patient.user_id == User.id).add_columns(
        User.name,
        User.email,
        Patient.phone,
        Patient.id
    ).all()
    
    return render_template('admin/manage_patients.html', patients=patients)

# Add routes for viewing patient details, etc. here...

# Add other admin routes here (e.g., manage doctors, patients, departments) 